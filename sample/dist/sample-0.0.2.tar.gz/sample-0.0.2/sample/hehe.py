def sample_print_stmt(lol: str) -> str:
    """This is a sample print stmt function
    params: lol: str: Requires a string
    """
    print(lol)
    return lol
